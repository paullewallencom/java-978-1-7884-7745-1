module com.example.datastructure.chapter_08_{
	exports com.example.searchtree;
	requires com.example.datastructure.chapter_02_;
	requires com.example.datastructure.chapter_04_;
	requires com.example.datastructure.chapter_05_;
	requires com.example.datastructure.chapter_07_;
}

module com.example.datastructure.chapter_07_{
	exports com.example.tree;
	requires com.example.datastructure.chapter_02_;
	requires com.example.datastructure.chapter_03_;
	requires com.example.datastructure.chapter_04_;
}

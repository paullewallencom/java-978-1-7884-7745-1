module com.example.datastructure.chapter_03_{
	exports com.example.adt;
	requires com.example.datastructure.chapter_02_;
}

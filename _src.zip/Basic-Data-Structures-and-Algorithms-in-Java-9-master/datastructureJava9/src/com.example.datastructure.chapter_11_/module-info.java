module com.example.datastructure.chapter_11_{
	exports com.example.reactive;
	requires com.example.datastructure.chapter_02_;
	requires com.example.datastructure.chapter_03_;
	requires com.example.datastructure.chapter_04_;
	requires com.example.datastructure.chapter_05_;
	requires com.example.datastructure.chapter_06_;
	requires com.example.datastructure.chapter_07_;
	requires com.example.datastructure.chapter_08_;
	requires com.example.datastructure.chapter_09_;
}

package com.example.functional;

/**
 * Created by debasishc on 27/8/16.
 */
@FunctionalInterface
public interface SampleFunctionalInterface {
    int modify(int x);
}

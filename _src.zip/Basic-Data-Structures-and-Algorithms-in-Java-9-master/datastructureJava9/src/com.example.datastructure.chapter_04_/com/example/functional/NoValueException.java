package com.example.functional;

/**
 * Created by debasishc on 28/8/16.
 */
public class NoValueException extends RuntimeException {
    public NoValueException(String message){
        super(message);
    }
}

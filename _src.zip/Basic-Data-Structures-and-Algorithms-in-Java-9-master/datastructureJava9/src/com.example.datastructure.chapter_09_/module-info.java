module com.example.datastructure.chapter_09_{
	exports com.example.priorityqueue;
	requires com.example.datastructure.chapter_02_;
	requires com.example.datastructure.chapter_03_;
}
